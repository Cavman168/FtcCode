package org.firstinspires.ftc.teamcode;

import com.arcrobotics.ftclib.hardware.motors.Motor;
import com.arcrobotics.ftclib.hardware.motors.MotorEx;
import com.google.common.base.Stopwatch;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.Servo;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;


@Autonomous
public class BackupAuto extends OpMode {
    double inpersec = 30.9; //36
    double tarposx = -24;
    double tarposy = 19;
    double xbuffer = 5; //prevbiousdly 15
    double ybuffer = 5;
    double processedx;
    double processedy;
    boolean xisnegative = false;
    boolean yisnegative = false;
    boolean xhasrun = false;
    boolean yhasrun = false;
    double posx;
    double posy;
    Stopwatch XTimer = Stopwatch.createUnstarted();
    Stopwatch YTimer = Stopwatch.createUnstarted();
    Stopwatch ActionsTimer = Stopwatch.createUnstarted();
    DcMotor spin, spin2, lfMotor, lbMotor, rfMotor, rbMotor, slide;
    Servo Grabber, light;
    CRServo suck, suck2;
    @Override
    public void init() {
        initrobot();

    }

    @Override
    public void loop() {
        main();
    }
    private void initrobot(){
        lbMotor = hardwareMap.get(DcMotor.class, "LB Motor");
        rbMotor = hardwareMap.get(DcMotor.class, "RB Motor");
        lfMotor = hardwareMap.get(DcMotor.class, "LF Motor");
        rfMotor = hardwareMap.get(DcMotor.class, "RF Motor");
        suck = hardwareMap.get(CRServo.class, "suck");
        suck2 = hardwareMap.get(CRServo.class, "suck2");
        spin = hardwareMap.get(DcMotor.class, "Spin");
        spin2 = hardwareMap.get(DcMotor.class, "Spin2");
        lfMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        lbMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        lbMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rbMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rfMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        lfMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    }
    private void main(){
        if(Math.abs(tarposx) > tarposx){
            xisnegative = true;
        }
        if(Math.abs(tarposy) > tarposy){
            yisnegative = true;
        }
        if(xisnegative){
            processedx = Math.abs(tarposx) / inpersec;
            if(!XTimer.isRunning() && !xhasrun){
                XTimer.start();
            }
            if(XTimer.isRunning()){
                lfMotor.setPower(-0.6);
                lbMotor.setPower(0.6);
                rfMotor.setPower(0.6);
                rbMotor.setPower(-0.6);
            }
        }
        if(!xisnegative){
            processedx = tarposx / inpersec;
            if(!XTimer.isRunning() && !xhasrun){
                XTimer.start();
            }
            if(XTimer.isRunning()){
                lfMotor.setPower(0.6);
                lbMotor.setPower(-0.6);
                rfMotor.setPower(-0.6);
                rbMotor.setPower(0.6);
            }
        }
        if(yisnegative){
            processedy = Math.abs(tarposy) / inpersec;
            if(!YTimer.isRunning() && !yhasrun && xhasrun){
                YTimer.start();
            }
            if(YTimer.isRunning()){
                lfMotor.setPower(-0.6);
                lbMotor.setPower(-0.6);
                rfMotor.setPower(-0.6);
                rbMotor.setPower(-0.6);
            }
        }
        if(!yisnegative){
            processedy = tarposy / inpersec;
            if(!YTimer.isRunning() && !yhasrun && xhasrun){
                YTimer.start();
            }
            if(YTimer.isRunning()){
                lfMotor.setPower(0.6);
                lbMotor.setPower(0.6);
                rfMotor.setPower(0.6);
                rbMotor.setPower(0.6);
            }
        }
        if(XTimer.isRunning() && XTimer.elapsed(TimeUnit.SECONDS) >= processedx){
            xhasrun = true;
            posx = tarposx;
            XTimer.reset();
        }
        if(YTimer.isRunning() && YTimer.elapsed(TimeUnit.SECONDS) >= processedy){
            yhasrun = true;
            posy = tarposy;
            YTimer.reset();
        }
        if(xhasrun && yhasrun || !XTimer.isRunning() && !YTimer.isRunning()){
            lfMotor.setPower(0);
            lbMotor.setPower(0);
            rfMotor.setPower(0);
            rbMotor.setPower(0);
        }
        telemetry.addData("st1", XTimer.elapsed(TimeUnit.SECONDS));
        telemetry.addData("st2", YTimer.elapsed(TimeUnit.SECONDS));
        telemetry.update();
    }
}
