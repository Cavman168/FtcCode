package org.firstinspires.ftc.teamcode.pedroPathing;

import com.pedropathing.follower.Follower;
import com.pedropathing.follower.FollowerConstants;
import com.pedropathing.ftc.localization.constants.OTOSConstants;
import com.pedropathing.ftc.localization.localizers.OTOSLocalizer;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.localization.Localizer;
import com.pedropathing.paths.PathBuilder;
import com.pedropathing.paths.PathChain;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.HardwareMap;

@Autonomous(name = "Test Path 2")
public class TestPath2 extends OpMode {

    private Follower follower;
    private PathChain paths;
    private int cycle;

    public PathBuilder builder;

    @Override
    public void init() {
        // ✅ Initialize Follower (this sets up drive and localization)
        follower = Constants.createFollower(hardwareMap);

        // ✅ Define starting pose (make sure it matches your path start)
        Pose startPose = new Pose(62.303, 9.268, Math.toRadians(90));
        follower.setPose(startPose);

        // ✅ Build your paths AFTER follower is initialized
        builder = new PathBuilder(follower);





        telemetry.addLine("Init complete - ready to start path");
    }
    public void autopath(){

        PathChain Path1 = builder
                .addPath(new BezierLine(new Pose(62.303, 9.268), new Pose(74.145, 22.656)))
                .setLinearHeadingInterpolation(Math.toRadians(90), Math.toRadians(180))
                .build();

        PathChain Path2 = builder
                .addPath(new BezierLine(new Pose(74.145, 22.656), new Pose(83.585, 9.611)))
                .setTangentHeadingInterpolation()
                .build();

        PathChain Path3 = builder
                .addPath(new BezierLine(new Pose(83.585, 9.611), new Pose(64.534, 19.738)))
                .setTangentHeadingInterpolation()
                .build();

        PathChain Path4 = builder
                .addPath(new BezierLine(new Pose(64.534, 19.738), new Pose(82.212, 20.253)))
                .setTangentHeadingInterpolation()
                .build();

        PathChain Path5 = builder
                .addPath(new BezierLine(new Pose(82.212, 20.253), new Pose(62.474, 8.925)))
                .setTangentHeadingInterpolation()
                .build();

        switch(cycle){
            case(0):
                if(!follower.isBusy()){
                    follower.followPath(Path1);
                    cycle = 1;
                }
                break;
            case(1):
                if(!follower.isBusy()){
                    follower.followPath(Path2);
                    cycle = 2;
                }
                break;
            case(2):
                if(!follower.isBusy()){
                    follower.followPath(Path3);
                    cycle = 3;
                }
                break;
            case(3):
                if(!follower.isBusy()){
                    follower.followPath(Path4);
                    cycle = 4;
                }
                break;
            case(4):
                if(!follower.isBusy()){
                    follower.followPath(Path5);
                    cycle = 5;
                }
                break;
            case(5):
                if(!follower.isBusy()){
                    cycle = -1;
                }
                break;
        }
    }

    @Override
    public void start() {
        // ✅ Begin following the path when op mode starts

    }

    @Override
    public void loop() {
        // ✅ Keep updating the follower so it drives the path
        autopath();
        follower.update();

        // ✅ Debug output to Driver Station
        Pose currentPose = follower.getPose();
        telemetry.addData("x", currentPose.getX());
        telemetry.addData("y", currentPose.getY());
        telemetry.addData("heading", Math.toDegrees(currentPose.getHeading()));
        telemetry.update();
    }
}
