package org.firstinspires.ftc.teamcode.pedroPathing;

import com.google.common.base.Stopwatch;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathBuilder;
import com.pedropathing.paths.PathChain;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.hardware.sparkfun.SparkFunOTOS;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.robotcore.external.navigation.YawPitchRollAngles;

import java.util.Arrays;

@TeleOp
public class NeoDriv extends OpMode {
    double xbuffer, ybuffer, hbuffer, xtargetpos, ytargetpos, htarget;
    boolean ignorehbuffer = false;
    DcMotor lbMotor, lfMotor, rbMotor, rfMotor, cannon, turret;
    Servo turret2;
    Limelight3A limelight;
    boolean pee, alliancecolor; // red:false, blue:true
    public SparkFunOTOS myOtos;
    private Follower follower;
    private PathChain paths;
    private int pathN, apriltagcode;

    public PathBuilder builder;

    Stopwatch[] stopwatches = new Stopwatch[9];
    @Override
    public void init() {
        InitDrive();
    }

    @Override
    public void loop() {
        Main();
    }
    private void InitDrive(){
        myOtos = hardwareMap.get(SparkFunOTOS.class, "Lazor");
        lbMotor = hardwareMap.get(DcMotor.class, "LB Motor");
        rbMotor = hardwareMap.get(DcMotor.class, "RB Motor");
        lfMotor = hardwareMap.get(DcMotor.class, "LF Motor");
        rfMotor = hardwareMap.get(DcMotor.class, "RF Motor");

        cannon = hardwareMap.get(DcMotor.class, "Cannon");
        turret = hardwareMap.get(DcMotor.class, "Turret");
        //turret2 = hardwareMap.get(Servo.class, "Turret2");
        cannon.setDirection(DcMotorSimple.Direction.REVERSE);
        lfMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        lbMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        rbMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        //rfMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        SparkFunOTOS Lazor = myOtos;
        Arrays.fill(stopwatches, Stopwatch.createUnstarted());
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        limelight.setPollRateHz(100); // This sets how often we ask Limelight for data (100 times per second)
        limelight.start(); // This tells Limelight to start looking!

        xbuffer = 5;
        ybuffer = 5;
        hbuffer = 4;

        // ✅ Initialize Follower (this sets up drive and localization)
        follower = Constants.createFollower(hardwareMap);

        // ✅ Define starting pose (make sure it matches your path start)
        Pose startPose = new Pose(62.303, 9.268, Math.toRadians(90));
        follower.setPose(startPose);

        // ✅ Build your paths AFTER follower is initialized
        builder = new PathBuilder(follower);

        pee = false;
        pathN = 0;

        double tx, ta, ty;
    }
    private void Main(){
        //limelight.updateRobotOrientation(orientation.getYaw(AngleUnit.DEGREES));
        LLResult result = limelight.getLatestResult();
        Drive();
        CamOut();
        launchtemp();
        trackout();
        switch (pathN){
            case(0): pee = false;
            case(1): // path 1...
        }

        if(result != null && result.isValid()){
            //calculate distances for turret
        }
        else{turret.setPower(0.5);/*search for apriltag*/}
    }
    private void Drive(){
        double drive = -gamepad1.left_stick_y;
        double strafe = gamepad1.left_stick_x;
        double rotate = gamepad1.right_stick_x;

        double lfPower = drive + strafe + rotate;
        double rfPower = drive - strafe - rotate;
        double lbPower = drive - strafe + rotate;
        double rbPower = drive + strafe - rotate;

        lfMotor.setPower(lfPower);
        rfMotor.setPower(rfPower);
        lbMotor.setPower(lbPower);
        rbMotor.setPower(rbPower);
    }
    private void CamOut(){
        LLResult result = limelight.getLatestResult();
        if (result != null && result.isValid()) {
            double tx = result.getTx(); // How far left or right the target is (degrees)
            double ty = result.getTy(); // How far up or down the target is (degrees)
            double ta = result.getTa(); // How big the target looks (0%-100% of the image)

            telemetry.addData("Target X", tx);
            telemetry.addData("Target Y", ty);
            telemetry.addData("Target Area", ta);
        } else {
            telemetry.addData("Limelight", "No Targets");
        }
    }
    private void launchtemp(){
        if(gamepad1.dpad_up){
            cannon.setPower(1);
        } else if (gamepad1.dpad_down) {
            cannon.setPower(-1);
        } else{cannon.setPower(0);}
    }
    private void trackout(){
        SparkFunOTOS.Pose2D pos = myOtos.getPosition();
        // Log the position to the telemetry
        telemetry.addData("X coordinate", pos.x);
        telemetry.addData("Y coordinate", pos.y);
        telemetry.addData("Heading angle", pos.h);

        // Update the telemetry on the driver station
        telemetry.update();
    }
    private void robottopos() { // For (Optional) use of automation`
    }

}
