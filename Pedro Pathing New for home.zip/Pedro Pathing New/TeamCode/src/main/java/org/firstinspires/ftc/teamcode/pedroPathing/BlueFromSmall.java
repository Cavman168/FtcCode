package org.firstinspires.ftc.teamcode.pedroPathing;

import com.bylazar.configurables.annotations.Configurable;
import com.bylazar.telemetry.PanelsTelemetry;
import com.bylazar.telemetry.TelemetryManager;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierCurve;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.pedroPathing.Constants;

@Autonomous
@Configurable // Panels
public class BlueFromSmall extends OpMode {

    private TelemetryManager panelsTelemetry; // Panels Telemetry instance
    public Follower follower; // Pedro Pathing follower instance
    private int pathState; // Current autonomous path state (state machine)
    private Paths paths; // Paths defined in the Paths class
    DcMotor cannon, cannon2; // replace with intake later

    @Override
    public void init() {
        panelsTelemetry = PanelsTelemetry.INSTANCE.getTelemetry();

        follower = Constants.createFollower(hardwareMap);
        follower.setStartingPose(new Pose(58, 9, Math.toRadians(90)));

        paths = new Paths(follower); // Build paths

        panelsTelemetry.debug("Status", "Initialized");
        panelsTelemetry.update(telemetry);
    }

    @Override
    public void loop() {
        //set intake power
        //cannon.setPower(1);
        //.setPower(1);

        follower.update(); // Update Pedro Pathing
        pathState = autonomousPathUpdate(); // Update autonomous state machine

        // Log values to Panels and Driver Station
        panelsTelemetry.debug("Path State", pathState);
        panelsTelemetry.debug("X", follower.getPose().getX());
        panelsTelemetry.debug("Y", follower.getPose().getY());
        panelsTelemetry.debug("Heading", follower.getPose().getHeading());
        panelsTelemetry.update(telemetry);
    }

    public static class Paths {

        public PathChain Path1;
        public PathChain Path2;
        public PathChain Path3;
        public PathChain Path4;
        public PathChain Path5;
        public PathChain Path6;
        public PathChain Path7;
        public PathChain Path8;

        public Paths(Follower follower) {
            Path1 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierLine(new Pose(58.184, 9.268), new Pose(72.429, 22.827))
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(90), Math.toRadians(120))
                    .build();

            Path2 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    new Pose(72.429, 22.827),
                                    new Pose(61.959, 37.759),
                                    new Pose(16.820, 35.871)
                            )
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(120), Math.toRadians(180))
                    .build();

            Path3 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierLine(new Pose(16.820, 35.871), new Pose(72.429, 22.484))
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(180), Math.toRadians(120))
                    .build();

            Path4 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierCurve(
                                    new Pose(72.429, 22.484),
                                    new Pose(69.511, 60.415),
                                    new Pose(17.163, 59.728)
                            )
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(120), Math.toRadians(180))
                    .build();

            Path5 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierLine(new Pose(17.163, 59.728), new Pose(58.698, 85.473))
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(180), Math.toRadians(135))
                    .build();

            Path6 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierLine(new Pose(58.698, 85.473), new Pose(15.962, 83.585))
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(135), Math.toRadians(180))
                    .build();

            Path7 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierLine(new Pose(15.962, 83.585), new Pose(58.698, 85.816))
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(180), Math.toRadians(135))
                    .build();

            Path8 = follower
                    .pathBuilder()
                    .addPath(
                            new BezierLine(new Pose(58.698, 85.816), new Pose(55.094, 88.563))
                    )
                    .setLinearHeadingInterpolation(Math.toRadians(135), Math.toRadians(135))
                    .build();
        }
    }

    public int autonomousPathUpdate() {
        // Add your state machine Here
        // Access paths with paths.pathName
        // Refer to the Pedro Pathing Docs (Auto Example) for an example state machine
        switch (pathState){
            case 0:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path1);
                    //score preloads
                    pathState = 1;
                }
                break;
            case 1:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path2);
                    pathState = 2;
                }
                break;
            case 2:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path3);
                    pathState = 3;
                }
                break;
            case 3:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path4);
                    pathState = 4;
                }
                break;
            case 4:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path5);
                    //score preloads
                    pathState = 5;
                }
                break;
            case 5:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path6);
                    pathState = 6;
                }
                break;
            case 6:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path7);
                    pathState = 7;
                }
                break;
            case 7:
                if(!follower.isBusy()){
                    follower.followPath(paths.Path8);
                    pathState = 8;
                }
                break;
            case 8:
                if(!follower.isBusy()){
                    pathState = -1;
                }
        }
        return pathState;
    }
}
