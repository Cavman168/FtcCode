package org.firstinspires.ftc.teamcode.pedroPathing;

import com.google.common.base.Stopwatch;
import com.qualcomm.hardware.sparkfun.SparkFunOTOS;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

@TeleOp
public class TestDriv extends OpMode {
    DcMotor lbMotor, lfMotor, rbMotor, rfMotor, cannon, turretcannon;
    Servo kicker, pivot, pivot2;
    //ColorSensor color;
    //public SparkFunOTOS myOtos;
    int redv, greenv, bluev;
    int COLOR;
    boolean nocolor;
    Stopwatch[] stopwatches = new Stopwatch[9];
    public  SparkFunOTOS myOtos;
    @Override
    public void init() {
        InitDrive();
    }

    @Override
    public void loop() {
        Main();
    }
    private void InitDrive(){
        //myOtos = hardwareMap.get(SparkFunOTOS.class, "Lazor");
        lbMotor = hardwareMap.get(DcMotor.class, "LB Motor");
        rbMotor = hardwareMap.get(DcMotor.class, "RB Motor");
        lfMotor = hardwareMap.get(DcMotor.class, "LF Motor");
        rfMotor = hardwareMap.get(DcMotor.class, "RF Motor");

        kicker = hardwareMap.get(Servo.class, "Kicker");
        pivot = hardwareMap.get(Servo.class, "Pivot");
        pivot2 = hardwareMap.get(Servo.class, "Pivot2");

        //color = hardwareMap.get(ColorSensor.class, "Color");

        cannon = hardwareMap.get(DcMotor.class, "Cannon");
        turretcannon = hardwareMap.get(DcMotor.class, "Turretcannon");
        cannon.setDirection(DcMotorSimple.Direction.REVERSE);
        lfMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        lbMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        rbMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        //rfMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        SparkFunOTOS Lazor = myOtos;
        Arrays.fill(stopwatches, Stopwatch.createUnstarted());
        //trackbase();
    }
    public void Main(){
        //redv = color.red();
        //greenv = color.green();
        //bluev = color.blue();
        Drive();
        Cam();
        launchtemp();
        kicktemp();
        Telemetry();
        //trackout();
    }
    private void Drive(){
        double drive = -gamepad1.left_stick_y;
        double strafe = gamepad1.left_stick_x;
        double rotate = gamepad1.right_stick_x;

        double lfPower = drive + strafe + rotate;
        double rfPower = drive - strafe - rotate;
        double lbPower = drive - strafe + rotate;
        double rbPower = drive + strafe - rotate;

        lfMotor.setPower(lfPower);
        rfMotor.setPower(rfPower);
        lbMotor.setPower(lbPower);
        rbMotor.setPower(rbPower);
    }
    private void Cam(){
        if(bluev < 500 && greenv < 500){
            nocolor = true;
        }
        else{nocolor = false;}

        if(greenv > bluev && !nocolor){
            //green
            COLOR = 2;
        } else if (bluev > greenv && !nocolor) {
            //purple

            COLOR = 1;
        }
        else{COLOR = 0;}
    }
    private void kicktemp(){
        kicker.setPosition(gamepad1.right_trigger);
    }
    private void launchtemp(){
        if(gamepad1.dpad_up && !stopwatches[1].isRunning()){
            cannon.setPower(1);
            stopwatches[1].start();
        } else if (gamepad1.dpad_down && !stopwatches[1].isRunning()) {
            cannon.setPower(-1);
            stopwatches[1].start();
        }
        if(stopwatches[1].isRunning() && stopwatches[1].elapsed(TimeUnit.MILLISECONDS) > 400){
            stopwatches[1].reset();
        }
        if(gamepad1.dpad_right && !stopwatches[2].isRunning()){
            pivot.setPosition(pivot.getPosition() + 0.05);
            pivot2.setPosition(pivot2.getPosition() + 0.05);
            stopwatches[2].start();
        } else if (gamepad1.dpad_left && !stopwatches[2].isRunning()) {
            pivot.setPosition(pivot.getPosition() - 0.05);
            pivot2.setPosition(pivot2.getPosition() - 0.05);
            stopwatches[2].start();
        }
        if(stopwatches[2].isRunning() && stopwatches[2].elapsed(TimeUnit.MILLISECONDS) > 400){
            stopwatches[2].reset();
        }
        turretcannon.setPower(-gamepad1.left_trigger);
    }
    private void Telemetry(){
        telemetry.addData("kicker", kicker.getPosition());
        telemetry.addData("cannon1", cannon.getPower());
        telemetry.addData("COlOR", COLOR);
        telemetry.addData("Redv", redv);
        telemetry.addData("Greenv", greenv);
        telemetry.addData("Bluev", bluev);
        //telemetry.addData("argb", color.argb());
        telemetry.update();
    }
    /*private void trackout(){
        SparkFunOTOS.Pose2D pos = myOtos.getPosition();
        // Log the position to the telemetry
        telemetry.addData("X coordinate", pos.x);
        telemetry.addData("Y coordinate", pos.y);
        telemetry.addData("Heading angle", pos.h);

        // Update the telemetry on the driver station
        telemetry.update();
    }
    private void trackbase(){
        telemetry.addLine("Configuring OTOS...");
        telemetry.update();

        // Set the desired units for linear and angular measurements. Can be either
        // meters or inches for linear, and radians or degrees for angular. If not
        // set, the default is inches and degrees. Note that this setting is not
        // persisted in the sensor, so you need to set at the start of all your
        // OpModes if using the non-default value.
        // myOtos.setLinearUnit(DistanceUnit.METER);
        myOtos.setLinearUnit(DistanceUnit.INCH);
        // myOtos.setAngularUnit(AnguleUnit.RADIANS);
        myOtos.setAngularUnit(AngleUnit.DEGREES);

        // Assuming you've mounted your sensor to a robot and it's not centered,
        // you can specify the offset for the sensor relative to the center of the
        // robot. The units default to inches and degrees, but if you want to use
        // different units, specify them before setting the offset! Note that as of
        // firmware version 1.0, these values will be lost after a power cycle, so
        // you will need to set them each time you power up the sensor. For example, if
        // the sensor is mounted 5 inches to the left (negative X) and 10 inches
        // forward (positive Y) of the center of the robot, and mounted 90 degrees
        // clockwise (negative rotation) from the robot's orientation, the offset
        // would be {-5, 10, -90}. These can be any value, even the angle can be
        // tweaked slightly to compensate for imperfect mounting (eg. 1.3 degrees).
        SparkFunOTOS.Pose2D offset = new SparkFunOTOS.Pose2D(0, 0, 0);
        myOtos.setOffset(offset);

        // Here we can set the linear and angular scalars, which can compensate for
        // scaling issues with the sensor measurements. Note that as of firmware
        // version 1.0, these values will be lost after a power cycle, so you will
        // need to set them each time you power up the sensor. They can be any value
        // from 0.872 to 1.127 in increments of 0.001 (0.1%). It is recommended to
        // first set both scalars to 1.0, then calibrate the angular scalar, then
        // the linear scalar. To calibrate the angular scalar, spin the robot by
        // multiple rotations (eg. 10) to get a precise error, then set the scalar
        // to the inverse of the error. Remember that the angle wraps from -180 to
        // 180 degrees, so for example, if after 10 rotations counterclockwise
        // (positive rotation), the sensor reports -15 degrees, the required scalar
        // would be 3600/3585 = 1.004. To calibrate the linear scalar, move the
        // robot a known distance and measure the error; do this multiple times at
        // multiple speeds to get an average, then set the linear scalar to the
        // inverse of the error. For example, if you move the robot 100 inches and
        // the sensor reports 103 inches, set the linear scalar to 100/103 = 0.971
        myOtos.setLinearScalar(1.0);
        myOtos.setAngularScalar(0.99064);

        // The IMU on the OTOS includes a gyroscope and accelerometer, which could
        // have an offset. Note that as of firmware version 1.0, the calibration
        // will be lost after a power cycle; the OTOS performs a quick calibration
        // when it powers up, but it is recommended to perform a more thorough
        // calibration at the start of all your OpModes. Note that the sensor must
        // be completely stationary and flat during calibration! When calling
        // calibrateImu(), you can specify the number of samples to take and whether
        // to wait until the calibration is complete. If no parameters are provided,
        // it will take 255 samples and wait until done; each sample takes about
        // 2.4ms, so about 612ms total
        myOtos.calibrateImu();

        // Reset the tracking algorithm - this resets the position to the origin,
        // but can also be used to recover from some rare tracking errors
        myOtos.resetTracking();

        // After resetting the tracking, the OTOS will report that the robot is at
        // the origin. If your robot does not start at the origin, or you have
        // another source of location information (eg. vision odometry), you can set
        // the OTOS location to match and it will continue to track from there.
        SparkFunOTOS.Pose2D currentPosition = new SparkFunOTOS.Pose2D(0, 0, 0);
        myOtos.setPosition(currentPosition);

        // Get the hardware and firmware version
        SparkFunOTOS.Version hwVersion = new SparkFunOTOS.Version();
        SparkFunOTOS.Version fwVersion = new SparkFunOTOS.Version();
        myOtos.getVersionInfo(hwVersion, fwVersion);

        telemetry.addLine("OTOS configured! Press start to get position data!");
        telemetry.addLine();
        telemetry.addLine(String.format("OTOS Hardware Version: v%d.%d", hwVersion.major, hwVersion.minor));
        telemetry.addLine(String.format("OTOS Firmware Version: v%d.%d", fwVersion.major, fwVersion.minor));
        telemetry.update();
    }*/
}
